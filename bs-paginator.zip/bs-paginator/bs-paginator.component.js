"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var BsPaginatorComponent = /** @class */ (function () {
    function BsPaginatorComponent() {
        this.pageChange = new core_1.EventEmitter();
    }
    BsPaginatorComponent.prototype.ngOnInit = function () {
    };
    BsPaginatorComponent.prototype.ngOnChanges = function () {
        this.calulatePaginationBound();
    };
    BsPaginatorComponent.prototype.pageChangeTrigger = function ($event) {
        if ($event !== 'PageSize')
            this.pageNo = $event;
        this.calulatePaginationBound();
        this.pageChange.emit({ pageNo: this.pageNo, pageSize: this.pageSize });
    };
    BsPaginatorComponent.prototype.calulatePaginationBound = function () {
        this.lower = this.pageSize * (this.pageNo - 1) + 1;
        this.upper = this.pageSize * this.pageNo > this.totalDataCount ? this.totalDataCount : this.pageSize * this.pageNo;
    };
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], BsPaginatorComponent.prototype, "pageNo", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], BsPaginatorComponent.prototype, "pageSize", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], BsPaginatorComponent.prototype, "totalDataCount", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Array)
    ], BsPaginatorComponent.prototype, "pageSizeOption", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Number)
    ], BsPaginatorComponent.prototype, "maxSize", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Boolean)
    ], BsPaginatorComponent.prototype, "rotate", void 0);
    __decorate([
        core_1.Input(),
        __metadata("design:type", Boolean)
    ], BsPaginatorComponent.prototype, "boundaryLinks", void 0);
    __decorate([
        core_1.Output(),
        __metadata("design:type", core_1.EventEmitter)
    ], BsPaginatorComponent.prototype, "pageChange", void 0);
    BsPaginatorComponent = __decorate([
        core_1.Component({
            selector: "bs-paginator",
            templateUrl: "./bs-paginator.component.html",
            styleUrls: ["./bs-paginator.component.css"],
            encapsulation: core_1.ViewEncapsulation.None
        })
    ], BsPaginatorComponent);
    return BsPaginatorComponent;
}());
exports.BsPaginatorComponent = BsPaginatorComponent;
//# sourceMappingURL=bs-paginator.component.js.map