﻿import { Component, ViewEncapsulation, Input, Output, EventEmitter, OnInit } from '@angular/core';


@Component({
    selector: "bs-paginator",
    templateUrl: "./bs-paginator.component.html",
    styleUrls: ["./bs-paginator.component.css"],
    encapsulation: ViewEncapsulation.None
})

export class BsPaginatorComponent implements OnInit {
    @Input() pageNo: number
    @Input() pageSize: number;
    @Input() totalDataCount: number;
    @Input() pageSizeOption: number[];
    @Input() maxSize: number;
    @Input() rotate: boolean;
    @Input() boundaryLinks: boolean;
    @Output() pageChange: EventEmitter<any> = new EventEmitter<any>();
    public lower;
    public upper;


    ngOnInit(): void {
        
    }
    ngOnChanges(): void {
        this.calulatePaginationBound();
    }

    pageChangeTrigger($event): void {
        if ($event !== 'PageSize')
            this.pageNo = $event;
        this.calulatePaginationBound();
        this.pageChange.emit({ pageNo: this.pageNo, pageSize: this.pageSize })
    }


    calulatePaginationBound(): void {
        this.lower = this.pageSize * (this.pageNo - 1) + 1
        this.upper = this.pageSize * this.pageNo > this.totalDataCount ? this.totalDataCount : this.pageSize * this.pageNo;
    }
}